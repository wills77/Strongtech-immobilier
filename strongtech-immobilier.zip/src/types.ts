export type PropertyType = 'Appartement' | 'Villa' | 'Terrain' | 'Bureau' | 'Local commercial';
export type FrenchCity = 'Paris' | 'Nice' | 'Lyon' | 'Bordeaux' | 'Marseille';

export interface Property {
  id: string;
  ref: string;
  title: string;
  type: PropertyType;
  city: FrenchCity;
  price: number;
  size: number; // in m²
  bedrooms: number;
  bathrooms: number;
  description: string;
  image: string;
  images: string[];
  features: string[];
  energyClass: 'A' | 'B' | 'C' | 'D' | 'E';
  gasClass: 'A' | 'B' | 'C' | 'D' | 'E';
  featured: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  description: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  stars: number;
  comment: string;
  image: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
}
