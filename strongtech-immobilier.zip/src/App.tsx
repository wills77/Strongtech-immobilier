import React, { useState, useEffect, useRef } from 'react';
import { 
  Home, 
  MapPin, 
  Maximize, 
  Bed, 
  Bath, 
  Search, 
  Mail, 
  Phone, 
  Clock, 
  Menu, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Star, 
  Check, 
  ArrowUp, 
  DollarSign, 
  Key, 
  TrendingUp, 
  Sparkles, 
  Building, 
  Award, 
  Shield, 
  Send 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PROPERTIES, GALLERY_ITEMS, TESTIMONIALS, SERVICES } from './data';
import { Property, GalleryItem, PropertyType, FrenchCity } from './types';

export default function App() {
  // Mobile menu visibility
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Search & Filter State
  const [selectedType, setSelectedType] = useState<PropertyType | 'Tous'>('Tous');
  const [selectedCity, setSelectedCity] = useState<FrenchCity | 'Toutes'>('Toutes');
  const [priceMin, setPriceMin] = useState<string>('');
  const [priceMax, setPriceMax] = useState<string>('');
  const [bedrooms, setBedrooms] = useState<string>('Tous');
  const [filteredProperties, setFilteredProperties] = useState<Property[]>(PROPERTIES);
  
  // Property Detail Modal State
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [activePhotoIndex, setActivePhotoIndex] = useState<number>(0);
  
  // Gallery Lightbox State
  const [activeLightboxIndex, setActiveLightboxIndex] = useState<number | null>(null);
  const [galleryCategory, setGalleryCategory] = useState<string>('Tous');
  
  // Scroll to Top float button visibility
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Animated Statistics State
  const [stats, setStats] = useState({
    propertiesSold: 0,
    experienceYears: 0,
    satisfactionRate: 0,
    exclusivePartners: 0
  });

  // Contact Form State
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [formSuccess, setFormSuccess] = useState(false);

  // Trigger Stat counters animation on load
  useEffect(() => {
    const duration = 2000; // 2 seconds
    const interval = 50; // every 50ms
    const steps = duration / interval;
    
    let stepCount = 0;
    const timer = setInterval(() => {
      stepCount++;
      setStats({
        propertiesSold: Math.round(Math.min((1450 / steps) * stepCount, 1450)),
        experienceYears: Math.round(Math.min((18 / steps) * stepCount, 18)),
        satisfactionRate: parseFloat((Math.min((99.7 / steps) * stepCount, 99.7)).toFixed(1)),
        exclusivePartners: Math.round(Math.min((45 / steps) * stepCount, 45))
      });
      
      if (stepCount >= steps) {
        clearInterval(timer);
      }
    }, interval);

    return () => clearInterval(timer);
  }, []);

  // Monitor scroll height to show back-to-top button
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 500) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Execute property filtering dynamically
  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    let result = PROPERTIES;

    // Filter by type
    if (selectedType !== 'Tous') {
      result = result.filter(p => p.type === selectedType);
    }

    // Filter by city
    if (selectedCity !== 'Toutes') {
      result = result.filter(p => p.city === selectedCity);
    }

    // Filter by Min price
    if (priceMin && !isNaN(Number(priceMin))) {
      result = result.filter(p => p.price >= Number(priceMin));
    }

    // Filter by Max price
    if (priceMax && !isNaN(Number(priceMax))) {
      result = result.filter(p => p.price <= Number(priceMax));
    }

    // Filter by bedrooms
    if (bedrooms !== 'Tous') {
      const bedsNum = Number(bedrooms);
      result = result.filter(p => p.bedrooms >= bedsNum);
    }

    setFilteredProperties(result);
  };

  // Run dynamic search instantly when essential dropdowns change to make UX exceptional
  useEffect(() => {
    handleSearch();
  }, [selectedType, selectedCity, bedrooms]);

  const resetFilters = () => {
    setSelectedType('Tous');
    setSelectedCity('Toutes');
    setPriceMin('');
    setPriceMax('');
    setBedrooms('Tous');
    setFilteredProperties(PROPERTIES);
  };

  // Open property details and preset image index to 0
  const openPropertyDetails = (property: Property) => {
    setSelectedProperty(property);
    setActivePhotoIndex(0);
  };

  // Open direct contact inquiry from visual property detail modal
  const sendInquiryFromProperty = (property: Property) => {
    setContactForm({
      ...contactForm,
      subject: `Demande d'informations — Réf: ${property.ref}`,
      message: `Bonjour, je suis vivement intéressé(e) par le bien "${property.title}" (Réf: ${property.ref}) situé à ${property.city}. Merci de me recontacter.`
    });
    setSelectedProperty(null);
    scrollToSection('contact-section');
  };

  // Smooth scroll helper
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setMobileMenuOpen(false);
  };

  // Gallery categorization filtering
  const filteredGalleryItems = galleryCategory === 'Tous' 
    ? GALLERY_ITEMS 
    : GALLERY_ITEMS.filter(item => item.category === galleryCategory);

  // Gallery Navigation inside Lightbox
  const handleNextLightbox = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeLightboxIndex === null) return;
    const nextIdx = (activeLightboxIndex + 1) % filteredGalleryItems.length;
    setActiveLightboxIndex(nextIdx);
  };

  const handlePrevLightbox = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeLightboxIndex === null) return;
    const prevIdx = (activeLightboxIndex - 1 + filteredGalleryItems.length) % filteredGalleryItems.length;
    setActiveLightboxIndex(prevIdx);
  };

  // Contact Form Submission Handler
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    
    if (!contactForm.name.trim()) {
      errors.name = 'Le nom complet est obligatoire.';
    }
    
    if (!contactForm.email.trim()) {
      errors.email = "L'adresse email est obligatoire.";
    } else if (!/\S+@\S+\.\S+/.test(contactForm.email)) {
      errors.email = "L'adresse email saisie est invalide.";
    }

    if (!contactForm.phone.trim()) {
      errors.phone = 'Le numéro de téléphone est obligatoire.';
    } else if (!/^[0-9+ ]{8,15}$/.test(contactForm.phone.replace(/[\s-]/g, ''))) {
      errors.phone = 'Numéro de téléphone incorrect.';
    }

    if (!contactForm.subject.trim()) {
      errors.subject = 'Le sujet du message est obligatoire.';
    }

    if (!contactForm.message.trim() || contactForm.message.length < 15) {
      errors.message = 'Le message doit contenir au moins 15 caractères.';
    }

    setFormErrors(errors);

    if (Object.keys(errors).length === 0) {
      // Simulate successful server persistence/transmission
      setFormSuccess(true);
      setContactForm({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      });
      
      // Auto dismiss success toast
      setTimeout(() => {
        setFormSuccess(false);
      }, 5000);
    }
  };

  return (
    <div className="min-h-screen bg-brand-blue-dark font-sans text-slate-200 antialiased selection:bg-brand-gold selection:text-brand-blue-dark">
      
      {/* HEADER SECTION */}
      <header id="accueil-section" className="sticky top-0 z-40 w-full border-b border-brand-gold/15 bg-brand-blue-dark/95 text-white backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => scrollToSection('accueil-section')}>
            <div className="relative flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-tr from-brand-gold to-brand-gold-dark text-brand-blue-dark shadow-md">
              <Building className="h-5 w-5" />
              <div className="absolute -top-1 -right-1 h-3.5 w-3.5 animate-ping rounded-full bg-brand-gold-light opacity-30"></div>
            </div>
            <div>
              <span className="font-display text-xl font-bold tracking-tight text-white select-none">
                StrongTech <span className="text-brand-gold font-sans font-medium">Immobilier</span>
              </span>
              <p className="text-[9px] uppercase tracking-widest text-[#B4966E] font-mono leading-none">Prestige & Excellence</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8 text-sm font-medium tracking-wide">
            <button onClick={() => scrollToSection('accueil-section')} className="transition-colors hover:text-brand-gold border-b-2 border-transparent hover:border-brand-gold py-1">Accueil</button>
            <button onClick={() => scrollToSection('biens-section')} className="transition-colors hover:text-brand-gold border-b-2 border-transparent hover:border-brand-gold py-1">Biens</button>
            <button onClick={() => scrollToSection('services-section')} className="transition-colors hover:text-brand-gold border-b-2 border-transparent hover:border-brand-gold py-1">À propos</button>
            <button onClick={() => scrollToSection('contact-section')} className="transition-colors hover:text-brand-gold border-b-2 border-transparent hover:border-brand-gold py-1">Contact</button>
          </nav>

          {/* Call to action */}
          <div className="hidden md:block">
            <button 
              onClick={() => scrollToSection('biens-section')}
              className="group relative flex items-center justify-center overflow-hidden rounded-md bg-brand-gold px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-brand-blue-dark transition-all hover:bg-brand-gold-dark hover:shadow-lg hover:shadow-brand-gold/20"
            >
              <span className="relative z-10">Voir les annonces</span>
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
            className="rounded-md p-2 text-slate-200 transition-colors hover:bg-brand-blue-medium hover:text-white md:hidden"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6 text-brand-gold" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation Panel */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="border-t border-brand-gold/15 bg-brand-blue-dark md:hidden overflow-hidden"
            >
              <div className="space-y-3 px-4 py-6 text-base font-medium">
                <button 
                  onClick={() => scrollToSection('accueil-section')} 
                  className="block w-full text-left py-2 border-l-4 border-transparent pl-3 hover:border-brand-gold hover:bg-brand-blue-medium/30 hover:text-brand-gold text-slate-100 transition-all"
                >
                  Accueil
                </button>
                <button 
                  onClick={() => scrollToSection('biens-section')} 
                  className="block w-full text-left py-2 border-l-4 border-transparent pl-3 hover:border-brand-gold hover:bg-brand-blue-medium/30 hover:text-brand-gold text-slate-100 transition-all"
                >
                  Nos Biens d’Exception
                </button>
                <button 
                  onClick={() => scrollToSection('services-section')} 
                  className="block w-full text-left py-2 border-l-4 border-transparent pl-3 hover:border-brand-gold hover:bg-brand-blue-medium/30 hover:text-brand-gold text-slate-100 transition-all"
                >
                  Services & À Propos
                </button>
                <button 
                  onClick={() => scrollToSection('contact-section')} 
                  className="block w-full text-left py-2 border-l-4 border-transparent pl-3 hover:border-brand-gold hover:bg-brand-blue-medium/30 hover:text-brand-gold text-slate-100 transition-all"
                >
                  Contacter l’Agence
                </button>
                <div className="pt-4 px-3">
                  <button 
                    onClick={() => scrollToSection('biens-section')}
                    className="flex w-full items-center justify-center rounded-md bg-brand-gold py-3 text-center text-xs font-semibold uppercase tracking-wider text-brand-blue-dark animate-pulse"
                  >
                    Voir les annonces
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* HERO SECTION */}
      <section className="relative flex min-h-[85vh] items-center justify-center bg-brand-blue-dark/95 text-white overflow-hidden py-16">
        
        {/* Absolute Background image */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1920&q=85" 
            alt="Manoir de standing et piscine" 
            className="h-full w-full object-cover opacity-35 filter brightness-75 scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark via-brand-blue-dark/60 to-transparent"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          
          {/* Tagline Animation */}
          <div className="mb-4 inline-flex items-center space-x-2 rounded-full border border-brand-gold/30 bg-brand-gold/10 px-4 py-1.5 backdrop-blur-md">
            <Sparkles className="h-4 w-4 text-brand-gold animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-widest text-[#F4E8C1]">Conseil et Immobilier Haut de Gamme</span>
          </div>

          <h1 className="mx-auto max-w-4xl font-display text-4xl font-semibold leading-tight tracking-tight sm:text-5xl lg:text-6xl text-white">
            Trouvez le bien immobilier <br />
            <span className="text-gradient bg-gradient-to-r from-brand-gold-light via-brand-gold to-brand-gold-dark bg-clip-text text-transparent">de vos rêves d’exception</span>
          </h1>
          
          <p className="mx-auto mt-6 max-w-2xl text-base text-slate-300 md:text-lg">
            StrongTech Immobilier réinvente la recherche de properties hauts de gamme. Découvrez notre sélection exclusive de villas de luxe, lofts urbains, et appartements d’influence.
          </p>

          {/* ADVANCED SEARCH ENGINE BAR */}
          <div className="mx-auto mt-12 w-full max-w-5xl rounded-2xl border border-brand-gold/15 bg-brand-blue-medium/60 p-6 shadow-2xl backdrop-blur-lg">
            <form onSubmit={handleSearch} className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5 text-left text-white">
              
              {/* Type Category */}
              <div className="flex flex-col space-y-1.5">
                <label className="text-xs font-semibold tracking-wide text-brand-gold-light uppercase">Type de Bien</label>
                <div className="relative">
                  <select 
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value as PropertyType | 'Tous')}
                    className="w-full rounded-lg border border-brand-gold/15 bg-brand-blue-dark/50 py-3 pl-3 pr-10 text-xs font-medium text-white focus:border-brand-gold focus:outline-none focus:ring-1 focus:ring-brand-gold cursor-pointer"
                  >
                    <option value="Tous" className="bg-[#050B18]">Tous les types</option>
                    <option value="Villa" className="bg-[#050B18]">Villa d’architecte</option>
                    <option value="Appartement" className="bg-[#050B18]">Appartement d’exception</option>
                    <option value="Bureau" className="bg-[#050B18]">Bureaux / Espaces Pro</option>
                    <option value="Local commercial" className="bg-[#050B18]">Local commercial</option>
                    <option value="Terrain" className="bg-[#050B18]">Terrain d’exception</option>
                  </select>
                </div>
              </div>

              {/* City Selection */}
              <div className="flex flex-col space-y-1.5">
                <label className="text-xs font-semibold tracking-wide text-brand-gold-light uppercase">Localisation</label>
                <div className="relative">
                  <select 
                    value={selectedCity}
                    onChange={(e) => setSelectedCity(e.target.value as FrenchCity | 'Toutes')}
                    className="w-full rounded-lg border border-brand-gold/15 bg-brand-blue-dark/50 py-3 pl-3 pr-10 text-xs font-medium text-white focus:border-brand-gold focus:outline-none focus:ring-1 focus:ring-brand-gold cursor-pointer"
                  >
                    <option value="Toutes" className="bg-[#050B18]">Paris, Nice, Lyon, Bordeaux, Marseille</option>
                    <option value="Paris" className="bg-[#050B18]">Paris (IDF)</option>
                    <option value="Nice" className="bg-[#050B18]">Nice (Côte d’Azur)</option>
                    <option value="Lyon" className="bg-[#050B18]">Lyon (Rhône)</option>
                    <option value="Bordeaux" className="bg-[#050B18]">Bordeaux (Gironde)</option>
                    <option value="Marseille" className="bg-[#050B18]">Marseille (Bouches-du-Rhône)</option>
                  </select>
                </div>
              </div>

              {/* Min & Max Price Fields */}
              <div className="grid grid-cols-2 gap-2">
                <div className="flex flex-col space-y-1.5">
                  <label className="text-xs font-semibold tracking-wide text-brand-gold-light uppercase">Budget Min</label>
                  <input 
                    type="number" 
                    placeholder="ex: 400 000€"
                    value={priceMin}
                    onChange={(e) => setPriceMin(e.target.value)}
                    className="w-full rounded-lg border border-brand-gold/15 bg-brand-blue-dark/50 p-3 text-xs text-white focus:border-brand-gold focus:outline-none focus:ring-1 focus:ring-brand-gold"
                  />
                </div>
                <div className="flex flex-col space-y-1.5">
                  <label className="text-xs font-semibold tracking-wide text-brand-gold-light uppercase">Budget Max</label>
                  <input 
                    type="number" 
                    placeholder="ex: 2 000 000€"
                    value={priceMax}
                    onChange={(e) => setPriceMax(e.target.value)}
                    className="w-full rounded-lg border border-brand-gold/15 bg-brand-blue-dark/50 p-3 text-xs text-white focus:border-brand-gold focus:outline-none focus:ring-1 focus:ring-brand-gold"
                  />
                </div>
              </div>

              {/* Bedrooms Count */}
              <div className="flex flex-col space-y-1.5">
                <label className="text-xs font-semibold tracking-wide text-brand-gold-light uppercase">Chambres minimum</label>
                <div className="relative">
                  <select 
                    value={bedrooms}
                    onChange={(e) => setBedrooms(e.target.value)}
                    className="w-full rounded-lg border border-brand-gold/15 bg-brand-blue-dark/50 py-3 pl-3 pr-10 text-xs font-medium text-white focus:border-brand-gold focus:outline-none focus:ring-1 focus:ring-brand-gold cursor-pointer"
                  >
                    <option value="Tous" className="bg-[#050B18]">Tous</option>
                    <option value="1" className="bg-[#050B18]">1 chambre +</option>
                    <option value="2" className="bg-[#050B18]">2 chambres +</option>
                    <option value="3" className="bg-[#050B18]">3 chambres +</option>
                    <option value="4" className="bg-[#050B18]">4 chambres +</option>
                    <option value="5" className="bg-[#050B18]">5 chambres +</option>
                  </select>
                </div>
              </div>

              {/* Search Actions */}
              <div className="flex flex-row space-x-2 items-end pt-4 sm:pt-0">
                <button 
                  type="submit" 
                  className="flex-1 flex items-center justify-center space-x-2 rounded-lg bg-brand-gold py-3 px-4 text-xs font-semibold uppercase tracking-wider text-brand-blue-dark hover:bg-brand-gold-dark transition-all cursor-pointer shadow-md"
                >
                  <Search className="h-4 w-4" />
                  <span>Filtrer</span>
                </button>
                <button 
                  type="button"
                  onClick={resetFilters}
                  title="Réinitialiser les filtres"
                  className="flex items-center justify-center rounded-lg bg-brand-blue-dark/50 text-slate-300 p-3 hover:bg-brand-blue-medium border border-brand-gold/15 transition-all cursor-pointer"
                >
                  <X className="h-4 w-4 text-slate-400" />
                </button>
              </div>

            </form>
          </div>

        </div>
      </section>

      {/* STATS SECTION (ANIMATED COUNTERS) */}
      <section className="bg-brand-blue-dark/40 py-12 border-t border-b border-brand-gold/15">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-8 text-center md:grid-cols-4">
            
            {/* Stat Item 1 */}
            <div className="flex flex-col items-center border-r border-brand-gold/10 last:border-0">
              <span className="font-display text-4xl font-bold tracking-tight text-brand-gold md:text-5xl">
                {stats.propertiesSold > 1400 ? `1 450+` : stats.propertiesSold}
              </span>
              <span className="mt-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Transactions d'exception</span>
            </div>

            {/* Stat Item 2 */}
            <div className="flex flex-col items-center border-r border-brand-gold/10 md:border-r last:border-0">
              <span className="font-display text-4xl font-bold tracking-tight text-brand-gold md:text-5xl">
                {stats.experienceYears >= 18 ? `18+` : `${stats.experienceYears}`} ans
              </span>
              <span className="mt-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Présence & Expertise</span>
            </div>

            {/* Stat Item 3 */}
            <div className="flex flex-col items-center border-r border-brand-gold/10 last:border-0">
              <span className="font-display text-4xl font-bold tracking-tight text-brand-gold md:text-5xl">
                {stats.satisfactionRate >= 99.7 ? `99.7%` : `${stats.satisfactionRate}%`}
              </span>
              <span className="mt-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Clients Satisfaits</span>
            </div>

            {/* Stat Item 4 */}
            <div className="flex flex-col items-center last:border-0">
              <span className="font-display text-4xl font-bold tracking-tight text-brand-gold md:text-5xl">
                {stats.exclusivePartners >= 45 ? `45+` : stats.exclusivePartners}
              </span>
              <span className="mt-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Partenaires exclusifs</span>
            </div>

          </div>
        </div>
      </section>

      {/* CORE PROPERTY LISTINGS SECTION */}
      <section id="biens-section" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Nos Biens Immobilier en Vedette
          </h2>
          <div className="mx-auto mt-3 h-1 w-16 bg-brand-gold rounded-full"></div>
          <p className="mx-auto mt-4 max-w-2xl text-sm text-slate-400">
            Une sélection unique d'appartements d'architectes, lofts contemporains et somptueuses villas haut de gamme de notre réseau national de confiance.
          </p>
        </div>

        {/* Dynamic active filtering pills for quicker navigation */}
        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {['Tous', 'Villa', 'Appartement', 'Bureau', 'Local commercial', 'Terrain'].map((type) => (
            <button
              key={type}
              onClick={() => setSelectedType(type as PropertyType | 'Tous')}
              className={`rounded-full px-5 py-1.5 text-xs font-medium tracking-wide transition-all ${
                (selectedType === type)
                  ? 'bg-brand-gold text-brand-blue-dark font-semibold shadow-md border-brand-gold/25'
                  : 'bg-brand-blue-dark/40 border border-brand-gold/15 text-slate-300 hover:bg-brand-blue-medium hover:text-white'
              }`}
            >
              {type === 'Tous' ? 'Tout Afficher' : type}
            </button>
          ))}
        </div>

        {/* Summary of found goods */}
        <div className="mt-6 flex items-center justify-between border-b border-brand-gold/15 pb-3 text-xs font-mono text-slate-400">
          <span>RÉSULTATS : {filteredProperties.length} BIEN{filteredProperties.length > 1 ? 'S' : ''} DISPONIBLE{filteredProperties.length > 1 ? 'S' : ''}</span>
          {filteredProperties.length !== PROPERTIES.length && (
            <button onClick={resetFilters} className="text-brand-gold hover:underline cursor-pointer font-sans font-semibold">Toutes les annonces</button>
          )}
        </div>

        {/* Property cards grid */}
        {filteredProperties.length === 0 ? (
          <div className="mt-16 text-center py-16 bg-brand-blue-dark/40 rounded-xl border border-dashed border-brand-gold/25">
            <Building className="mx-auto h-12 w-12 text-brand-gold" />
            <h3 className="mt-4 text-base font-semibold text-slate-200">Aucun résultat ne correspond à vos filtres de recherche.</h3>
            <p className="mt-2 text-xs text-slate-400">Essayez d’élargir vos budgets, de réduire le nombre de chambres ou de réinitialiser vos critères.</p>
            <button 
              onClick={resetFilters}
              className="mt-6 rounded-md bg-brand-gold px-4 py-2 text-xs font-semibold text-brand-blue-dark transition-colors hover:bg-brand-gold-dark"
            >
              Réinitialiser les filtres
            </button>
          </div>
        ) : (
          <div className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {filteredProperties.map((property) => (
              <article 
                key={property.id} 
                id={`property-card-${property.id}`}
                className="group relative flex flex-col overflow-hidden rounded-xl bg-brand-blue-medium/35 shadow-md border border-brand-gold/15 hover:border-brand-gold/30 hover:shadow-[0_0_20px_rgba(212,175,55,0.06)] hover:-translate-y-1 transition-all duration-300"
              >
                
                {/* Property Main Image & badge */}
                <div className="relative h-64 overflow-hidden bg-slate-950">
                  <img 
                    src={property.image} 
                    alt={property.title} 
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Category Pill Tag */}
                  <div className="absolute top-4 left-4 z-10 flex items-center gap-1.5 rounded-md bg-brand-blue-dark/90 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-brand-gold shadow-md">
                    <Sparkles className="h-3 w-3 text-brand-gold" />
                    {property.type}
                  </div>

                  {/* City Pin tag */}
                  <div className="absolute bottom-4 left-4 z-10 flex items-center space-x-1 rounded bg-slate-950/80 p-1.5 px-2.5 text-xs text-white backdrop-blur-sm">
                    <MapPin className="h-3 w-3 text-brand-gold" />
                    <span>{property.city}</span>
                  </div>

                  {/* Ref value tag */}
                  <div className="absolute top-4 right-4 z-10 rounded bg-slate-950/60 p-1.5 text-[10px] font-mono font-medium text-white backdrop-blur-sm">
                    Ref: {property.ref}
                  </div>
                </div>

                {/* Property Content Info */}
                <div className="flex flex-1 flex-col p-6">
                  
                  {/* Title & brief desc */}
                  <h3 className="font-display text-lg font-semibold text-slate-100 line-clamp-1 group-hover:text-brand-gold transition-colors">
                    {property.title}
                  </h3>
                  
                  {/* Price info bar */}
                  <div className="my-2 text-xl font-bold tracking-tight text-white flex items-center">
                    {property.price.toLocaleString('fr-FR')} <span className="ml-1 text-base text-brand-gold font-normal">€</span>
                  </div>

                  <p className="mt-1 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {property.description}
                  </p>

                  {/* Bed, bath, and sizes tags */}
                  <div className="mt-5 grid grid-cols-3 gap-2 border-y border-brand-gold/10 py-3 text-xs font-semibold text-slate-300">
                    
                    {/* Size tag */}
                    <div className="flex items-center space-x-1.5 justify-center border-r border-brand-gold/10 last:border-0">
                      <Maximize className="h-4 w-4 text-brand-gold flex-shrink-0" />
                      <span>{property.size} m²</span>
                    </div>

                    {/* Bed tag */}
                    <div className="flex items-center space-x-1.5 justify-center border-r border-brand-gold/10 last:border-0">
                      <Bed className="h-4 w-4 text-brand-gold flex-shrink-0" />
                      <span>{property.bedrooms > 0 ? `${property.bedrooms} p.` : 'N/A'}</span>
                    </div>

                    {/* Bath tag */}
                    <div className="flex items-center space-x-1.5 justify-center">
                      <Bath className="h-4 w-4 text-brand-gold flex-shrink-0" />
                      <span>{property.bathrooms > 0 ? `${property.bathrooms} sdb.` : 'N/A'}</span>
                    </div>

                  </div>

                  {/* Card bottom actions */}
                  <div className="mt-6 flex items-center justify-between">
                    <div className="flex items-center space-x-1">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-950/40 text-[9px] font-mono font-bold text-emerald-400 border border-emerald-500/20">
                        {property.energyClass}
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">DPE Classé</span>
                    </div>

                    <button 
                      onClick={() => openPropertyDetails(property)}
                      className="inline-flex items-center space-x-1 rounded border border-brand-gold/35 px-4 py-2 text-xs font-semibold text-brand-gold transition-all hover:bg-[#D4AF37] hover:text-brand-blue-dark shadow-sm cursor-pointer"
                    >
                      <span>Voir détails</span>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>

                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* CORE STATS GRID / GALLERY IMMOBILIÈRE */}
      <section className="bg-[#050B18]/70 text-white py-20 border-t border-brand-gold/15">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          <div className="text-center">
            <span className="text-xs font-bold uppercase tracking-widest text-brand-gold">Portfolio d'Inspirations</span>
            <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Galerie de nos Réalisations
            </h2>
            <div className="mx-auto mt-3 h-1 w-16 bg-brand-gold rounded-full"></div>
            <p className="mx-auto mt-4 max-w-2xl text-sm text-slate-400">
              Explorez en images l'harmonie, la sophistication et la finesse architecturale de nos propriétés d'architecture et décors d'intérieurs prestigieux.
            </p>
          </div>

          {/* Quick interactive gallery tabs */}
          <div className="mt-10 flex flex-wrap justify-center gap-2">
            {['Tous', 'Salon', 'Extérieur', 'Cuisine', 'Chambre', 'Spa', 'Piscine', 'Cave', 'Bureau'].map((cat) => (
              <button
                key={cat}
                onClick={() => setGalleryCategory(cat)}
                className={`rounded px-4 py-1.5 text-xs font-semibold tracking-wider transition-all uppercase ${
                  galleryCategory === cat 
                    ? 'bg-brand-gold text-brand-blue-dark shadow-md' 
                    : 'bg-brand-blue-medium text-slate-400 hover:bg-brand-blue-medium/80 hover:text-white border border-brand-gold/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Photo gallery grid */}
          <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
            {filteredGalleryItems.map((item, index) => {
              // Retrieve absolute index in data so that the Lightbox shows the correct photos
              const globalIndex = GALLERY_ITEMS.findIndex(gal => gal.id === item.id);
              
              return (
                <div 
                  key={item.id} 
                  id={`gallery-item-${item.id}`}
                  onClick={() => setActiveLightboxIndex(globalIndex)}
                  className="group relative cursor-pointer overflow-hidden rounded-lg bg-slate-950 aspect-square"
                >
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110 group-hover:rotate-1"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Elegant Golden Hover overlay */}
                  <div className="absolute inset-0 bg-brand-blue-dark/80 scale-90 opacity-0 group-hover:scale-100 group-hover:opacity-100 transition-all duration-300 flex flex-col justify-end p-4">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-brand-gold">{item.category}</span>
                    <h4 className="font-display text-sm font-semibold text-white mt-1">{item.title}</h4>
                    <p className="text-[11px] text-slate-300 line-clamp-2 mt-1 leading-normal font-light">{item.description}</p>
                    <div className="mt-3 flex h-6 w-6 items-center justify-center rounded bg-brand-gold text-brand-blue-dark self-end shadow">
                      <Search className="h-3 w-3" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* AGENCY SERVICES SECTION */}
      <section id="services-section" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-3 lg:items-center">
          
          {/* Introductory callout column */}
          <div className="space-y-6">
            <span className="text-xs font-bold uppercase tracking-widest text-brand-gold">Donner vie à vos projets</span>
            <h2 className="font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl leading-tight">
              Nos Services Immobiliers d’Excellence
            </h2>
            <div className="h-1 w-16 bg-brand-gold rounded-full"></div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Chez StrongTech Immobilier, nous croyons qu'une transaction immobilière de prestige requiert bien plus qu'une simple transaction financière. C'est une œuvre d'art faite d'expertises croisées, d'écoute attentive et de confiance sans faille.
            </p>
            <div className="pt-2">
              <button 
                onClick={() => scrollToSection('contact-section')}
                className="inline-flex items-center space-x-2 rounded bg-brand-gold px-6 py-3 text-xs font-semibold uppercase tracking-wider text-brand-blue-dark shadow-md hover:bg-brand-gold-dark transition-colors"
              >
                <span>Bénéficier d’un conseil gratuit</span>
                <TrendingUp className="h-4 w-4 text-brand-blue-dark" />
              </button>
            </div>
          </div>

          {/* Services grid container (2 columns in desktop) */}
          <div className="lg:col-span-2 grid gap-6 sm:grid-cols-2">
            {SERVICES.map((serv) => {
              // Match icon manually based on data structure
              let ServiceIcon = Home;
              if (serv.iconName === 'DollarSign') ServiceIcon = DollarSign;
              if (serv.iconName === 'Key') ServiceIcon = Key;
              if (serv.iconName === 'TrendingUp') ServiceIcon = TrendingUp;

              return (
                <div 
                  key={serv.id} 
                  id={`service-${serv.id}`}
                  className="rounded-xl border border-brand-gold/15 bg-brand-blue-medium/35 p-8 shadow-sm hover:border-brand-gold/30 hover:shadow-[0_0_20px_rgba(212,175,55,0.06)] transition-all duration-300"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-[#050B18] text-brand-gold shadow border border-brand-gold/15">
                    <ServiceIcon className="h-6 w-6 text-brand-gold" />
                  </div>
                  <h3 className="mt-5 text-lg font-semibold text-slate-100">{serv.title}</h3>
                  <p className="mt-2 text-xs text-slate-400 leading-relaxed font-light">{serv.description}</p>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* WHY CHOOSE US ASSURANCES GRID */}
      <section className="bg-brand-blue-dark py-16 text-white border-y border-brand-gold/15">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-display text-2xl font-semibold tracking-tight text-white mb-10">L’Engagement Qualité StrongTech</h2>
          <div className="grid gap-8 sm:grid-cols-3">
            <div className="p-4 space-y-3 flex flex-col items-center">
              <div className="rounded-full bg-[#050B18] border border-brand-gold/20 p-4 text-brand-gold animate-pulse">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-sm font-semibold tracking-wider text-brand-gold">Confidentialité Absolue</h3>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed font-light">Vos données personnelles et de transaction patrimoniale sont préservées sous le sceau de l’anonymat le plus strict.</p>
            </div>
            <div className="p-4 space-y-3 flex flex-col items-center">
              <div className="rounded-full bg-[#050B18] border border-brand-gold/20 p-4 text-brand-gold">
                <Award className="h-6 w-6" />
              </div>
              <h3 className="text-sm font-semibold tracking-wider text-brand-gold">Négociants Experts</h3>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed font-light">Nos conseillers bénéficient d’une formation continue d’excellence en droit, fiscalité et urbanisme de standings.</p>
            </div>
            <div className="p-4 space-y-3 flex flex-col items-center">
              <div className="rounded-full bg-[#050B18] border border-brand-gold/20 p-4 text-brand-gold">
                <Sparkles className="h-6 w-6" />
              </div>
              <h3 className="text-sm font-semibold tracking-wider text-brand-gold">Accompagnement Sur Mesure</h3>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed font-light">De la première modélisation de votre rêve d’investissement à la remise solennelle des clés, nous restons à vos côtés.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CLIENT TESTIMONIALS SECTION */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-gold">Avis De Nos Clients</span>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Témoignages & Retours d'Expériences
          </h2>
          <div className="mx-auto mt-3 h-1 w-16 bg-brand-gold rounded-full"></div>
          <p className="mx-auto mt-4 max-w-2xl text-sm text-slate-400">
            La clé de notre succès repose dans la confiance et la satisfaction infinie de nos acquéreurs et vendeurs de demeures d’influences.
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {TESTIMONIALS.map((test) => (
            <div 
              key={test.id} 
              id={`testimonial-${test.id}`}
              className="flex flex-col justify-between rounded-xl bg-brand-blue-medium/35 p-8 shadow-sm border border-brand-gold/15 relative hover:border-brand-gold/30 transition-all duration-300"
            >
              <div className="space-y-4">
                
                {/* Visual Stars */}
                <div className="flex text-amber-400 space-x-1">
                  {[...Array(test.stars)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-amber-400" />
                  ))}
                </div>

                <blockquote className="text-slate-300 text-xs italic font-light leading-relaxed">
                  "{test.comment}"
                </blockquote>
              </div>

              {/* Profile citation footer */}
              <div className="mt-8 flex items-center space-x-3.5 border-t border-brand-gold/10 pt-5">
                <img 
                  src={test.image} 
                  alt={test.name} 
                  className="h-10 w-10 rounded-full object-cover ring-2 ring-brand-gold/30"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <cite className="not-italic text-xs font-semibold text-slate-100 block">{test.name}</cite>
                  <span className="text-[10px] text-slate-450 font-medium">{test.role}</span>
                </div>
              </div>

              {/* Aesthetic quote symbol decoration overlay */}
              <span className="absolute top-6 right-8 text-6xl font-display text-white/5 leading-none select-none">”</span>
            </div>
          ))}
        </div>
      </section>

      {/* DETAILED GOOGLE MAPS / LOCATION SECTION */}
      <section className="bg-brand-blue-dark/80 py-16 text-white border-t border-brand-gold/15">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-5 lg:items-stretch">
            
            {/* Left coordinate card block */}
            <div className="lg:col-span-2 flex flex-col justify-between bg-brand-blue-medium/50 p-8 rounded-xl border border-brand-gold/15">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-brand-gold">Notre Siège Social</span>
                <h3 className="mt-2 font-display text-2xl font-semibold text-white">L’Agence Parisienne</h3>
                <p className="mt-4 text-xs text-slate-300 leading-relaxed font-light">
                  Idéalement située au cœur du triangle d'or parisien, notre agence vous accueille en toute discrétion pour étudier la valorisation de votre patrimoine immobilier d'exception.
                </p>

                {/* Listing of helpful information details */}
                <div className="mt-8 space-y-4">
                  <div className="flex items-start space-x-3">
                    <MapPin className="h-5 w-5 text-brand-gold flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-white">Adresse</p>
                      <p className="text-xs text-slate-300 font-light">42 Avenue des Champs-Élysées, 75008 Paris</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Phone className="h-5 w-5 text-brand-gold flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-white">Ligne Directe</p>
                      <a href="tel:+33145678900" className="text-xs text-brand-gold hover:underline font-semibold">+33 (0)1 45 67 89 00</a>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Mail className="h-5 w-5 text-brand-gold flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-white">Courriel Secrétariat</p>
                      <a href="mailto:contact@strongtech.immobilier.fr" className="text-xs text-brand-gold hover:underline font-semibold">contact@strongtech-immobilier.fr</a>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Clock className="h-5 w-5 text-brand-gold flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-white">Heures d'Ouverture</p>
                      <p className="text-xs text-slate-300 font-light">Lundi au Vendredi : 9h00 – 19h00 | Samedi : sur rendez-vous</p>
                    </div>
                  </div>
                </div>
              </div>

              <p className="mt-8 text-[11px] text-slate-450 border-t border-brand-gold/10 pt-4 leading-normal font-light">
                * Un parking sécurisé est à disposition de notre aimable clientèle. Service voiturier disponible sur simple demande.
              </p>
            </div>

            {/* Right Map frame block */}
            <div className="lg:col-span-3 rounded-xl overflow-hidden shadow-lg min-h-[350px] relative border border-brand-gold/15 bg-brand-blue-medium/55">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1m4!2sChamps-Élysées!2m2!1d2.3025!2d48.8698!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fec703fdb89%3A0x111613eb4474d284!2sAvenue%20des%20Champs-Élysées%2C%20Paris!5e0!3m2!1sfr!2sfr!4v1700000000000!5m2!1sfr!2sfr"
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy" 
                title="Emplacement agence StrongTech Immobilier"
                referrerPolicy="no-referrer-when-downgrade"
                className="absolute inset-0 grayscale contrast-125 brightness-75 opacity-70"
              ></iframe>
            </div>

          </div>
        </div>
      </section>

      {/* CONTACT FORM COMPONENT SECTION */}
      <section id="contact-section" className="mx-auto max-w-4xl px-4 py-20 sm:px-6">
        
        <div className="text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-gold">Formulaire de Contact</span>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Prendre Contact avec nos Négociateurs
          </h2>
          <div className="mx-auto mt-3 h-1 w-16 bg-brand-gold rounded-full"></div>
          <p className="mx-auto mt-4 max-w-xl text-xs text-slate-400 leading-relaxed font-light">
            Pour toute demande d’évaluation confidentielle ou d’information concernant un de nos prestigieux properties, veuillez remplir le formulaire de contact ci-dessous.
          </p>
        </div>

        {/* Form container card setup */}
        <div className="mt-12 rounded-2xl border border-brand-gold/15 bg-brand-blue-medium/35 p-8 shadow-xl relative overflow-hidden">
          
          {/* Animated/timed absolute success banner overlay */}
          <AnimatePresence>
            {formSuccess && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-brand-blue-dark/98 border border-brand-gold/25 text-center p-6 text-white"
              >
                <div className="rounded-full bg-emerald-500 p-4 text-brand-blue-dark shadow mb-4">
                  <Check className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-brand-gold">Message transmis avec succès !</h3>
                <p className="mt-2 max-w-md text-xs text-slate-300 leading-relaxed">
                  Votre demande a bien été enregistrée par notre secrétariat d'affaires de standing. Un conseiller d'exception dédié de l'agence StrongTech vous recontactera sous 2 heures ouvrées rattachées.
                </p>
                <button 
                  onClick={() => setFormSuccess(false)}
                  className="mt-6 rounded border border-brand-gold px-5 py-2 text-xs font-medium text-brand-gold hover:bg-brand-gold hover:text-brand-blue-dark transition-all cursor-pointer font-semibold"
                >
                  Envoyer un nouveau message
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          <form onSubmit={handleContactSubmit} className="space-y-6">
            
            {/* Line 1: Name and Email */}
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="flex flex-col space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase">Nom complet <span className="text-brand-gold">*</span></label>
                <input 
                  type="text" 
                  placeholder="ex: Jean Dupont"
                  value={contactForm.name}
                  onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                  className={`rounded-md border p-3 text-xs focus:outline-none focus:ring-1 bg-[#050B18]/50 text-white border-brand-gold/20 ${
                    formErrors.name 
                      ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                      : 'border-brand-gold/15 focus:ring-brand-gold focus:border-brand-gold'
                  }`}
                />
                {formErrors.name && <span className="text-[10px] text-red-400 font-medium font-mono">{formErrors.name}</span>}
              </div>

              <div className="flex flex-col space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase">Adresse email <span className="text-brand-gold">*</span></label>
                <input 
                  type="email" 
                  placeholder="ex: jean.dupont@email.com"
                  value={contactForm.email}
                  onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                  className={`rounded-md border p-3 text-xs focus:outline-none focus:ring-1 bg-[#050B18]/50 text-white border-brand-gold/20 ${
                    formErrors.email 
                      ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                      : 'border-brand-gold/15 focus:ring-brand-gold focus:border-brand-gold'
                  }`}
                />
                {formErrors.email && <span className="text-[10px] text-red-400 font-medium font-mono">{formErrors.email}</span>}
              </div>
            </div>

            {/* Line 2: Phone and Subject */}
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="flex flex-col space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase">Téléphone <span className="text-brand-gold">*</span></label>
                <input 
                  type="tel" 
                  placeholder="ex: +33 6 12 34 56 78"
                  value={contactForm.phone}
                  onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                  className={`rounded-md border p-3 text-xs focus:outline-none focus:ring-1 bg-[#050B18]/50 text-white border-brand-gold/20 ${
                    formErrors.phone 
                      ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                      : 'border-brand-gold/15 focus:ring-brand-gold focus:border-brand-gold'
                  }`}
                />
                {formErrors.phone && <span className="text-[10px] text-red-400 font-medium font-mono">{formErrors.phone}</span>}
              </div>

              <div className="flex flex-col space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase">Sujet <span className="text-brand-gold">*</span></label>
                <input 
                  type="text" 
                  placeholder="ex: Question sur la Villa Saphir ST-829A"
                  value={contactForm.subject}
                  onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                  className={`rounded-md border p-3 text-xs focus:outline-none focus:ring-1 bg-[#050B18]/50 text-white border-brand-gold/20 ${
                    formErrors.subject 
                      ? 'border-red-500 focus:ring-red-550 focus:border-red-550' 
                      : 'border-brand-gold/15 focus:ring-brand-gold focus:border-brand-gold'
                  }`}
                />
                {formErrors.subject && <span className="text-[10px] text-red-400 font-medium font-mono">{formErrors.subject}</span>}
              </div>
            </div>

            {/* Text Message Field */}
            <div className="flex flex-col space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 uppercase">Votre Message <span className="text-brand-gold">*</span></label>
              <textarea 
                rows={5}
                placeholder="Décrivez votre projet d'acquisition, d'investissement ou d'évaluation de patrimoine avec les détails nécessaires..."
                value={contactForm.message}
                onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                className={`rounded-md border p-3 text-xs focus:outline-none focus:ring-1 leading-relaxed bg-[#050B18]/50 text-white border-brand-gold/20 ${
                  formErrors.message 
                    ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                    : 'border-brand-gold/15 focus:ring-brand-gold focus:border-brand-gold'
                }`}
              ></textarea>
              {formErrors.message && <span className="text-[10px] text-red-400 font-medium font-mono">{formErrors.message}</span>}
            </div>

            {/* Submit layout button */}
            <div className="pt-2 text-right">
              <button 
                type="submit" 
                className="group inline-flex items-center space-x-2 rounded bg-brand-gold py-3.5 px-8 text-xs font-semibold uppercase tracking-wider text-brand-blue-dark shadow-md hover:bg-brand-gold-dark transition-all cursor-pointer"
              >
                <span>Envoyer ma demande</span>
                <Send className="h-4 w-4 text-brand-blue-dark group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

          </form>

        </div>
      </section>

      {/* FOOTER AREA */}
      <footer className="bg-brand-blue-dark border-t border-brand-gold/15 text-slate-400 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-4">
            
            {/* Col 1: About Area details */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3 cursor-pointer" onClick={() => scrollToSection('accueil-section')}>
                <div className="flex h-9 w-9 items-center justify-center rounded bg-gradient-to-tr from-brand-gold to-brand-gold-dark text-brand-blue-dark font-bold shadow">
                  <Building className="h-4 w-4" />
                </div>
                <span className="font-display text-lg font-bold tracking-tight text-white">StrongTech <span className="text-brand-gold font-sans font-medium">Immo</span></span>
              </div>
              <p className="text-xs text-slate-400 font-light leading-relaxed">
                Une signature reconnue dans l’univers de l’immobilier de grand standing en France. Spécialiste de la transaction d'actifs d'exceptions.
              </p>
              
              <div className="pt-2 space-y-1 text-xs">
                <p className="text-white font-semibold">Titulaires CPF - Carte Professionnelle</p>
                <p className="font-mono text-[10px] text-slate-500">N° CPI 7501 2018 000 034 405 (CCI Paris-IDF)</p>
              </div>
            </div>

            {/* Col 2: Navigation Links */}
            <div>
              <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-white">Liens Rapides</h3>
              <ul className="mt-4 space-y-2 text-xs">
                <li><button onClick={() => scrollToSection('accueil-section')} className="transition-colors hover:text-brand-gold">Accueil principal</button></li>
                <li><button onClick={() => scrollToSection('biens-section')} className="transition-colors hover:text-brand-gold">Biens haut de gamme</button></li>
                <li><button onClick={() => scrollToSection('services-section')} className="transition-colors hover:text-brand-gold">À propos & Services</button></li>
                <li><button onClick={() => scrollToSection('contact-section')} className="transition-colors hover:text-brand-gold">Contacter nos négociateurs</button></li>
                <li><a href="#" onClick={(e) => { e.preventDefault(); alert("Exemple de Conditions de vente."); }} className="transition-colors hover:text-brand-gold">Mentions légales & RGPD</a></li>
              </ul>
            </div>

            {/* Col 3: Support Cities listings */}
            <div>
              <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-white">Villes Vedettes</h3>
              <ul className="mt-4 space-y-2 text-xs">
                <li><button onClick={() => { setSelectedCity('Paris'); scrollToSection('biens-section'); }} className="transition-colors hover:text-brand-gold">Prestige Parisien (75)</button></li>
                <li><button onClick={() => { setSelectedCity('Nice'); scrollToSection('biens-section'); }} className="transition-colors hover:text-brand-gold">Domaines sur la Côte d’Azur (06)</button></li>
                <li><button onClick={() => { setSelectedCity('Bordeaux'); scrollToSection('biens-section'); }} className="transition-colors hover:text-brand-gold">Propriétés Bordelaises & Arcachon (33)</button></li>
                <li><button onClick={() => { setSelectedCity('Lyon'); scrollToSection('biens-section'); }} className="transition-colors hover:text-brand-gold">Lofts Contemporains Lyonnais (69)</button></li>
                <li><button onClick={() => { setSelectedCity('Marseille'); scrollToSection('biens-section'); }} className="transition-colors hover:text-brand-gold">Résidences Littoral Marseille (13)</button></li>
              </ul>
            </div>

            {/* Col 4: Newsletter Box */}
            <div className="space-y-4">
              <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-white">Le Club Privé</h3>
              <p className="text-xs text-slate-400 leading-relaxed font-light">
                Inscrivez-vous à notre lettre d’information confidentielle (Newsletter) "Off-Market" pour recevoir chaque mois l'accès à 3 propriétés uniques non publiées.
              </p>
              
              <div className="flex h-10 w-full overflow-hidden rounded bg-[#050B18]/50 border border-brand-gold/15">
                <input 
                  type="email" 
                  placeholder="Votre adresse email" 
                  aria-label="Adresse email club privé"
                  className="flex-1 px-3 text-xs text-white focus:outline-none bg-transparent" 
                />
                <button 
                  onClick={() => alert("Bienvenue au Club Privé StrongTech ! Vous recevrez nos annonces Off-Market en priorité.")}
                  className="bg-brand-gold px-4 text-xs font-semibold text-brand-blue-dark hover:bg-brand-gold-dark transition-colors cursor-pointer"
                >
                  S'inscrire
                </button>
              </div>
            </div>

          </div>

          {/* Social icons & copyright baseline */}
          <div className="mt-12 flex flex-col justify-between border-t border-brand-gold/10 pt-8 sm:flex-row text-center sm:text-left text-xs font-mono font-light text-slate-450 border-brand-gold/10">
            <div>
              <p>© {new Date().getFullYear()} StrongTech Immobilier. Tous droits réservés.</p>
              <p className="mt-1 text-[10px]">Développé conformément aux standards de prestige en architecture.</p>
            </div>
            
            <div className="mt-4 sm:mt-0 flex justify-center space-x-6 text-sm font-sans font-medium text-slate-400">
              <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-brand-gold transition-colors">Facebook</a>
              <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-brand-gold transition-colors">Instagram</a>
              <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-brand-gold transition-colors">LinkedIn</a>
              <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-brand-gold transition-colors">YouTube</a>
            </div>
          </div>

        </div>
      </footer>

      {/* PROPERTY DETAILS MODAL VIEW */}
      <AnimatePresence>
        {selectedProperty && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Modal backdrop overlay shadow */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProperty(null)}
              className="fixed inset-0 bg-[#050B18]/90 backdrop-blur-md cursor-pointer"
            ></motion.div>

            {/* Modal actual card layout */}
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative z-10 flex flex-col w-full max-w-5xl overflow-hidden rounded-2xl bg-brand-blue-medium text-slate-200 shadow-2xl border border-brand-gold/20 max-h-[90vh]"
            >
              
              {/* Close float button */}
              <button 
                onClick={() => setSelectedProperty(null)}
                className="absolute top-4 right-4 z-25 flex h-10 w-10 items-center justify-center rounded-full bg-brand-blue-dark/60 text-white border border-brand-gold/15 backdrop-blur-sm hover:bg-brand-blue-dark transition-colors shadow cursor-pointer"
                aria-label="Fermer"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="flex-1 overflow-y-auto">
                <div className="grid gap-8 lg:grid-cols-12 p-6 sm:p-8">
                  
                  {/* Left Column: Extensive Gallery / Slide elements */}
                  <div className="lg:col-span-7 space-y-4">
                    
                    {/* Featured Image view */}
                    <div className="relative h-[340px] sm:h-[400px] overflow-hidden rounded-xl bg-slate-950 border border-brand-gold/15">
                      <img 
                        src={selectedProperty.images[activePhotoIndex]} 
                        alt={`${selectedProperty.title} - angle ${activePhotoIndex}`} 
                        className="h-full w-full object-cover transition-all"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Left and Right inline chevron absolute button navigations inside details slider */}
                      {selectedProperty.images.length > 1 && (
                        <>
                          <button 
                            onClick={() => {
                              const prevIdx = (activePhotoIndex - 1 + selectedProperty.images.length) % selectedProperty.images.length;
                              setActivePhotoIndex(prevIdx);
                            }}
                            className="absolute left-3 top-1/2 -translate-y-1/2 flex h-9 w-9 items-center justify-center rounded-full bg-[#050B18]/70 text-brand-gold hover:bg-[#050B18] transition-all cursor-pointer border border-brand-gold/10"
                          >
                            <ChevronLeft className="h-5 w-5" />
                          </button>
                          <button 
                            onClick={() => {
                              const nextIdx = (activePhotoIndex + 1) % selectedProperty.images.length;
                              setActivePhotoIndex(nextIdx);
                            }}
                            className="absolute right-3 top-1/2 -translate-y-1/2 flex h-9 w-9 items-center justify-center rounded-full bg-[#050B18]/70 text-brand-gold hover:bg-[#050B18] transition-all cursor-pointer border border-brand-gold/10"
                          >
                            <ChevronRight className="h-5 w-5" />
                          </button>
                        </>
                      )}

                      <div className="absolute bottom-4 right-4 z-10 rounded bg-[#050B18]/90 p-1.5 px-3 text-[10px] font-mono font-medium text-white backdrop-blur-sm">
                        {activePhotoIndex + 1} / {selectedProperty.images.length} PHOTOS
                      </div>
                    </div>

                    {/* Active Thumbnails List selection */}
                    {selectedProperty.images.length > 1 && (
                      <div className="grid grid-cols-4 gap-2">
                        {selectedProperty.images.map((photo, thumbIdx) => (
                          <button
                            key={thumbIdx}
                            onClick={() => setActivePhotoIndex(thumbIdx)}
                            className="relative h-20 overflow-hidden rounded-lg bg-slate-950 border-2 transition-all cursor-pointer border-transparent hover:border-brand-gold/30"
                          >
                            <img 
                              src={photo} 
                              alt="Vignette" 
                              className="h-full w-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </button>
                        ))}
                      </div>
                    )}

                  </div>

                  {/* Right Column: Key Details, and Actions */}
                  <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
                    <div className="space-y-4">
                      
                      {/* Meta pills list */}
                      <div className="flex flex-wrap gap-2 text-[10px] font-bold uppercase tracking-widest">
                        <span className="rounded bg-[#050B18] border border-brand-gold/15 px-2.5 py-1 text-brand-gold">{selectedProperty.type}</span>
                        <span className="rounded bg-brand-blue-dark border border-brand-gold/10 px-2.5 py-1 text-slate-300">{selectedProperty.city}</span>
                        <span className="rounded bg-brand-blue-dark/60 border border-brand-gold/10 px-2.5 py-1 text-slate-400 font-mono">Ref: {selectedProperty.ref}</span>
                      </div>

                      <h3 className="font-display text-xl sm:text-2xl font-bold text-white leading-snug">
                        {selectedProperty.title}
                      </h3>

                      {/* Display Premium Price tag value */}
                      <div className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white animate-fade-in">
                        {selectedProperty.price.toLocaleString('fr-FR')} <span className="text-lg font-medium text-brand-gold">€ F.A.I</span>
                      </div>

                      {/* Primary parameters (m², bedrooms, etc.) */}
                      <div className="grid grid-cols-3 gap-2 rounded-xl bg-[#050B18]/50 p-4 border border-brand-gold/10 text-center text-xs font-semibold">
                        <div>
                          <p className="text-slate-400 font-normal">Superficie</p>
                          <p className="mt-1 text-white text-sm font-bold">{selectedProperty.size} m²</p>
                        </div>
                        <div>
                          <p className="text-slate-400 font-normal">Chambres</p>
                          <p className="mt-1 text-white text-sm font-bold">{selectedProperty.bedrooms > 0 ? selectedProperty.bedrooms : 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 font-normal">Sdb / Eau</p>
                          <p className="mt-1 text-white text-sm font-bold">{selectedProperty.bathrooms > 0 ? selectedProperty.bathrooms : 'N/A'}</p>
                        </div>
                      </div>

                      {/* Descriptive narrative */}
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Description</h4>
                        <p className="text-xs text-slate-300 leading-relaxed font-light">
                          {selectedProperty.description}
                        </p>
                      </div>

                      {/* Features Checklists list */}
                      {selectedProperty.features && (
                        <div>
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Prestations & Commodités</h4>
                          <ul className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
                            {selectedProperty.features.map((feature, featIdx) => (
                              <li key={featIdx} className="flex items-center space-x-1 text-slate-350 font-light">
                                <Check className="h-4 w-4 text-brand-gold flex-shrink-0" />
                                <span className="line-clamp-1">{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* DPE Indicators visual charts bar */}
                      <div className="border-t border-brand-gold/10 pt-4 grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">Diagnostic Énergie (DPE)</span>
                          <div className="flex items-center space-x-2">
                            <div className={`flex h-10 w-12 items-center justify-center rounded-lg text-sm font-mono font-black text-white ${
                              selectedProperty.energyClass === 'A' ? 'bg-[#009b02]' :
                              selectedProperty.energyClass === 'B' ? 'bg-[#a3d900]' :
                              selectedProperty.energyClass === 'C' ? 'bg-[#fbc02d]' : 'bg-[#f57c00]'
                            }`}>
                              {selectedProperty.energyClass}
                            </div>
                            <span className="text-[10px] text-slate-400 leading-tight font-light">Consommation performante</span>
                          </div>
                        </div>

                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">Gaz Effet de Serre (GES)</span>
                          <div className="flex items-center space-x-2">
                            <div className={`flex h-10 w-12 items-center justify-center rounded-lg text-sm font-mono font-black text-white ${
                              selectedProperty.gasClass === 'A' ? 'bg-[#009b02]' :
                              selectedProperty.gasClass === 'B' ? 'bg-[#a3d900]' :
                              selectedProperty.gasClass === 'C' ? 'bg-[#fbc02d]' : 'bg-[#f57c00]'
                            }`}>
                              {selectedProperty.gasClass}
                            </div>
                            <span className="text-[10px] text-slate-400 leading-tight font-light">Émissions contrôlées</span>
                          </div>
                        </div>
                      </div>

                    </div>

                    {/* Bottom transaction Actions */}
                    <div className="pt-6 border-t border-brand-gold/10 flex flex-col sm:flex-row gap-3">
                      <button 
                        onClick={() => sendInquiryFromProperty(selectedProperty)}
                        className="flex-1 rounded bg-brand-gold py-3.5 px-4 text-center text-xs font-bold uppercase tracking-wider text-brand-blue-dark shadow-md hover:bg-brand-gold-dark transition-colors inline-flex justify-center items-center space-x-2 cursor-pointer font-semibold"
                      >
                        <Mail className="h-4 w-4 text-brand-blue-dark" />
                        <span>Demander une visite</span>
                      </button>
                      <button 
                        onClick={() => {
                          alert(`Appeler le négociateur réf: ${selectedProperty.ref} au +33 (0)1 45 67 89 00`);
                        }}
                        className="rounded border border-brand-gold/25 bg-[#050B18]/40 py-3.5 px-6 text-center text-xs font-bold uppercase tracking-wider text-brand-gold hover:bg-[#050B18] transition-colors"
                      >
                        Appeler
                      </button>
                    </div>

                  </div>

                </div>
              </div>

            </motion.div>

          </div>
        )}
      </AnimatePresence>

      {/* FULL GALLERY LIGHTBOX MODAL */}
      <AnimatePresence>
        {activeLightboxIndex !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Immersive backdrop background */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveLightboxIndex(null)}
              className="absolute inset-0 lightbox-overlay cursor-pointer"
            ></motion.div>

            {/* Lightbox center slider */}
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="relative z-10 w-full max-w-4xl text-white outline-none"
            >
              
              {/* Close light action */}
              <button 
                onClick={() => setActiveLightboxIndex(null)}
                className="absolute -top-12 right-0 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-all cursor-pointer text-white"
                aria-label="Fermer la galerie"
              >
                <X className="h-6 w-6" />
              </button>

              {/* Photo component display */}
              <div className="relative overflow-hidden rounded-xl shadow-2xl border border-brand-gold/20 bg-slate-950 flex flex-col justify-center items-center aspect-[4/3] sm:aspect-[16/10]">
                
                <img 
                  src={filteredGalleryItems[activeLightboxIndex]?.image} 
                  alt={filteredGalleryItems[activeLightboxIndex]?.title} 
                  className="max-h-[70vh] max-w-full object-contain pointer-events-none"
                  referrerPolicy="no-referrer"
                />

                {/* Left/Right controls inside lightbox */}
                {filteredGalleryItems.length > 1 && (
                  <>
                    <button 
                      onClick={handlePrevLightbox}
                      className="absolute left-4 top-1/2 -translate-y-1/2 flex h-12 w-12 items-center justify-center rounded-full bg-slate-950/70 text-brand-gold hover:bg-slate-900 border border-brand-gold/20 transition-all cursor-pointer"
                      aria-label="Précédent"
                    >
                      <ChevronLeft className="h-6 w-6" />
                    </button>
                    <button 
                      onClick={handleNextLightbox}
                      className="absolute right-4 top-1/2 -translate-y-1/2 flex h-12 w-12 items-center justify-center rounded-full bg-slate-950/70 text-brand-gold hover:bg-slate-900 border border-brand-gold/20 transition-all cursor-pointer"
                      aria-label="Suivant"
                    >
                      <ChevronRight className="h-6 w-6" />
                    </button>
                  </>
                )}

                {/* Captions area overlay inside lightbox */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-6 text-left">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-brand-gold">
                    {filteredGalleryItems[activeLightboxIndex]?.category} — PHOTO {activeLightboxIndex + 1} SUR {filteredGalleryItems.length}
                  </span>
                  <h4 className="font-display text-lg sm:text-xl font-bold mt-1 text-white">
                    {filteredGalleryItems[activeLightboxIndex]?.title}
                  </h4>
                  <p className="text-xs text-slate-350 leading-relaxed font-light mt-1.5 line-clamp-2">
                    {filteredGalleryItems[activeLightboxIndex]?.description}
                  </p>
                </div>

              </div>

            </motion.div>

          </div>
        )}
      </AnimatePresence>

      {/* FLOAT BUTTON SCROLL BACK TO TOP */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-6 right-6 z-40 flex h-12 w-12 items-center justify-center rounded-full bg-brand-gold text-brand-blue-dark shadow-xl hover:bg-brand-gold-dark hover:scale-105 transition-all outline-none border border-brand-gold-dark cursor-pointer"
            title="Retourner en haut de page"
          >
            <ArrowUp className="h-5 w-5" />
          </motion.button>
        )}
      </AnimatePresence>

    </div>
  );
}
