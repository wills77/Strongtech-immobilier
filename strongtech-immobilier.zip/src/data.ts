import { Property, GalleryItem, Testimonial, ServiceItem } from './types';

export const PROPERTIES: Property[] = [
  {
    id: 'prop-1',
    ref: 'ST-829A',
    title: 'Villa Saphir Épurée avec Piscine à Débordement',
    type: 'Villa',
    city: 'Nice',
    price: 1350000,
    size: 280,
    bedrooms: 5,
    bathrooms: 4,
    description: 'Une somptueuse villa contemporaine nichée sur les hauteurs de Nice, offrant une vue panoramique époustouflante sur la mer Méditerranée. Équipée d’une piscine à débordement de 12 mètres, d’une cuisine d’été et d’un salon extérieur grand luxe.',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Piscine à débordement', 'Vue Mer', 'Garage double', 'Domotique intégrée', 'Climatisation réversible'],
    energyClass: 'A',
    gasClass: 'A',
    featured: true
  },
  {
    id: 'prop-2',
    ref: 'ST-102B',
    title: 'Penthouse Haussmannien d’Exception',
    type: 'Appartement',
    city: 'Paris',
    price: 2450000,
    size: 165,
    bedrooms: 3,
    bathrooms: 2,
    description: 'Au dernier étage d’un somptueux immeuble en pierre de taille, ce penthouse unique offre une terrasse de 40 m² de plain-pied sans aucun vis-à-vis. Moulures d’époque d’une finesse rare, cheminées en marbre fonctionnelles et parquets en point de Hongrie.',
    image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Terrasse plein ciel', 'Dernier étage', 'Ascenseur direct', 'Cave à vin', 'Cheminées d’origine'],
    energyClass: 'B',
    gasClass: 'C',
    featured: true
  },
  {
    id: 'prop-3',
    ref: 'ST-455C',
    title: 'Bureaux Innovants Premium au Cœur de la Part-Dieu',
    type: 'Bureau',
    city: 'Lyon',
    price: 890000,
    size: 240,
    bedrooms: 0,
    bathrooms: 3,
    description: 'Espace de travail professionnel ultra-moderne, configuré en open-space avec plusieurs salles de réunion acoustiques séparées. Emplacement stratégique d’affaires à forte valeur ajoutée, idéal pour des startups technologiques ou un cabinet d’avocats prestigieux.',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Fibre optique pro', 'Salles de réunion', 'Cuisine équipée commune', 'Accès PMR', 'Climatisation centrale'],
    energyClass: 'B',
    gasClass: 'B',
    featured: false
  },
  {
    id: 'prop-4',
    ref: 'ST-301D',
    title: 'Local Commercial Triple Vitrine Centre Historique',
    type: 'Local commercial',
    city: 'Bordeaux',
    price: 520000,
    size: 98,
    bedrooms: 0,
    bathrooms: 1,
    description: 'Une superbe opportunité commerciale dotée d’un linéaire de vitrine de plus de 9 mètres au cœur d’une zone piétonne extrêmement passante de Bordeaux. Cave saine pour stockage incluse. Idéal boutique de créateurs ou joaillerie de standing.',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Triple vitrine blindée', 'Zone piétonne premium', 'Cave voûtée active', 'Rideau de fer électrique'],
    energyClass: 'C',
    gasClass: 'C',
    featured: false
  },
  {
    id: 'prop-5',
    ref: 'ST-019E',
    title: 'Terrain Viabilisé Vue Collines pour Projet d’Exception',
    type: 'Terrain',
    city: 'Nice',
    price: 450000,
    size: 1600,
    bedrooms: 0,
    bathrooms: 0,
    description: 'Magnifique terrain en restanques douces de 1 600 m² entièrement viabilisé (eau, électricité, tout-à-l’égout, télécoms) dans un quartier résidentiel de grand standing. Libre choix de constructeur pour bâtir une villa à l’architecture ambitieuse.',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Entièrement viabilisé', 'Libre constructeur', 'CES favorable de 15%', 'Orientation Plein Sud'],
    energyClass: 'A',
    gasClass: 'A',
    featured: false
  },
  {
    id: 'prop-6',
    ref: 'ST-712F',
    title: 'Villa Belvédère Contemporaine Flanc de Falaise',
    type: 'Villa',
    city: 'Marseille',
    price: 1980000,
    size: 310,
    bedrooms: 4,
    bathrooms: 4,
    description: 'Une merveille d’architecture moderne taillée dans la roche sur les hauteurs du littoral marseillais. Toit-terrasse panoramique, ascenseur intérieur en verre reliant l’ensemble des niveaux, piscine en couloir de nage et larges baies vitrées coulissantes.',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Ascenseur vitré', 'Couloir de nage', 'Toit-terrasse panoramique', 'Système audio Focal intégré'],
    energyClass: 'A',
    gasClass: 'A',
    featured: true
  },
  {
    id: 'prop-7',
    ref: 'ST-563G',
    title: 'Loft Industriel Canut en Duplex Rénové',
    type: 'Appartement',
    city: 'Lyon',
    price: 640000,
    size: 125,
    bedrooms: 2,
    bathrooms: 2,
    description: 'Ancien atelier de soyeux lyonnais converti en loft contemporain d’une élégance rare. Hauteur sous plafond magistrale de 4,8 mètres, poutres d’époque sablées, escalier sur mesure en acier brossé et grande verrière donnant sur une cour privée verdoyante.',
    image: 'https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Hauteur sous plafond 4M80', 'Verrière monumentale', 'Climatisation', 'Cuisine américaine premium'],
    energyClass: 'B',
    gasClass: 'B',
    featured: false
  },
  {
    id: 'prop-8',
    ref: 'ST-900H',
    title: 'Appartement de Prestige en Bord de Mer',
    type: 'Appartement',
    city: 'Nice',
    price: 820000,
    size: 95,
    bedrooms: 2,
    bathrooms: 1,
    description: 'Situé sur la célèbre Promenade des Anglais, cet appartement offre un balcon spacieux offrant un panorama à 180° sur la Baie des Anges. Entièrement rénové avec des matériaux nobles, placards sur mesure et mobilier italien raffiné inclus.',
    image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Direct Promenade des Anglais', 'Balcon face mer', 'Marbre blanc de Carrare', 'Garde de sécurité 24h/24'],
    energyClass: 'C',
    gasClass: 'B',
    featured: true
  },
  {
    id: 'prop-9',
    ref: 'ST-224I',
    title: 'Bureaux Triplex d’Exception Place des Vosges',
    type: 'Bureau',
    city: 'Paris',
    price: 3600000,
    size: 320,
    bedrooms: 0,
    bathrooms: 4,
    description: 'Adresse de prestige absolu sur l’une des plus belles places historiques du monde. Ces bureaux agencés sur 3 niveaux combinent éléments d’époque classés (plafonds peints à caissons, boiseries) et infrastructures réseaux ultra-modernes de classe Gigabit.',
    image: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Adresse Place des Vosges', 'Infrastructures réseau pro', 'Double accès privé', 'Climatisation autonome'],
    energyClass: 'D',
    gasClass: 'D',
    featured: true
  },
  {
    id: 'prop-10',
    ref: 'ST-822J',
    title: 'Villa d’Architecte Bois et Verre dans la Pinède',
    type: 'Villa',
    city: 'Bordeaux',
    price: 1150000,
    size: 220,
    bedrooms: 4,
    bathrooms: 3,
    description: 'À l’orée des forêts de pins girondines et à seulement 30 minutes de Bordeaux centre, cette villa à ossature bois haut de gamme se fond entièrement dans la nature. Spa de nage en extérieur, poêle à bois nordique moderne et terrasses suspendues.',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Ossature bois écologique', 'Spa de nage', 'Poêle à bois scandinave', 'Calme absolu sans vis-à-vis'],
    energyClass: 'A',
    gasClass: 'A',
    featured: false
  },
  {
    id: 'prop-11',
    ref: 'ST-112K',
    title: 'Local Commercial Angle Stratégique et Passage',
    type: 'Local commercial',
    city: 'Marseille',
    price: 490000,
    size: 85,
    bedrooms: 0,
    bathrooms: 1,
    description: 'Implantation commerciale de premier ordre bénéficiant d’une visibilité d’angle extraordinaire entre deux des axes commerçants les plus recherchés du Vieux-Port. Évacuation d’air haute performance intégrée (idéal salon de thé haut de gamme ou franchise renommée).',
    image: 'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Emplacement Vieux-Port', 'Extraction d’air en place', 'Double linéaire vitré', 'Rénovation neuve'],
    energyClass: 'B',
    gasClass: 'B',
    featured: false
  },
  {
    id: 'prop-12',
    ref: 'ST-574L',
    title: 'Terrain Littoral constructible d’Exception',
    type: 'Terrain',
    city: 'Bordeaux',
    price: 610000,
    size: 2100,
    bedrooms: 0,
    bathrooms: 0,
    description: 'Terrain forestier d’une surface exceptionnelle proche du bassin d’Arcachon et des vignobles bordelais. Entouré de chênes centenaires, ce terrain plat bénéficie d’un coefficient d’emprise au sol généreux permettant de réaliser un domaine de maître complet.',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
    images: [
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80'
    ],
    features: ['Proche Bassin d’Arcachon', 'Grands arbres classés sauvés', 'Exposition ouest magnifique', 'Accès direct privé'],
    energyClass: 'A',
    gasClass: 'A',
    featured: false
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: "Le Grand Salon Contemporain",
    category: "Salon",
    image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1000&q=80",
    description: "Un espace ouvert et lumineux alliant marbre poli, boiseries nobles et baies vitrées de 6 mètres de haut."
  },
  {
    id: 'gal-2',
    title: "Terrasse Suspendue Face Mer",
    category: "Extérieur",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80",
    description: "Terrasse en teck birman flottant au-dessus des vagues azures, agrémentée de transats design Italiens."
  },
  {
    id: 'gal-3',
    title: "Cuisine de Chef Intégrée",
    category: "Cuisine",
    image: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1000&q=80",
    description: "Électroménager Gaggenau encastré, îlot central en quartz noir et cave de maturation à portée de main."
  },
  {
    id: 'gal-4',
    title: "Suite Master Royale",
    category: "Chambre",
    image: "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=1000&q=80",
    description: "Suite de 45 m² avec lit king-size suspendu, dressing attenant et écran cinéma escamotable."
  },
  {
    id: 'gal-5',
    title: "Bulle de Bien-Être & Spa",
    category: "Spa",
    image: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1000&q=80",
    description: "Salle de bain royale avec douche à effet pluie tropicale, sauna infra-rouge et baignoire en îlot sculpté."
  },
  {
    id: 'gal-6',
    title: "Couloir d’Eau Infinie",
    category: "Piscine",
    image: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?auto=format&fit=crop&w=1000&q=80",
    description: "Superbe piscine en couloir de nage éclairée par fibre optique créant un effet de nuit étoilée."
  },
  {
    id: 'gal-7',
    title: "Cave Secrète de Vieillissement",
    category: "Cave",
    image: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1000&q=80",
    description: "Espace climatisé creusé dans le calcaire pour préserver les plus grands crus classés."
  },
  {
    id: 'gal-8',
    title: "Espace de Bureau Panoramique",
    category: "Bureau",
    image: "https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1000&q=80",
    description: "Un bureau de direction spacieux, baigné de lumière naturelle, offrant sérénité et inspiration."
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Jean-Pierre & Hélène Clavel',
    role: 'Acquéreurs d’une villa à Nice',
    stars: 5,
    comment: 'L’équipe de StrongTech Immobilier a su cerner notre projet en quelques minutes seulement. La Villa Saphir qui nous a été proposée dépasse largement nos attentes. Le service d’accompagnement juridique est d’un professionnalisme hors pair !',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&h=200&q=80'
  },
  {
    id: 'test-2',
    name: 'Alexandra Valois',
    role: 'Vendeuse d’un appartement à Paris',
    stars: 5,
    comment: 'Une vente réalisée hors marché (off-market) en moins de deux semaines au prix d’estimation. La discrétion absolue, l’élégance de la communication et l’efficacité de StrongTech font toute la différence.',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&h=200&q=80'
  },
  {
    id: 'test-3',
    name: 'Marc-Antoine Ségur',
    role: 'Investisseur foncier (Bordeaux & Lyon)',
    stars: 5,
    comment: 'Troisième opération avec l’agence StrongTech Immobilier et l’excellence reste constante. Les conseils stratégiques en investissement immobilier et leur réactivité sur les ventes exclusives garantissent des plus-values précieuses.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80'
  }
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'serv-1',
    title: 'Achat d’Exception',
    description: 'Accédez à notre catalogue exclusif d’appartements d’époque, terrasses de prestige et villas signatures inédites.',
    iconName: 'Home'
  },
  {
    id: 'serv-2',
    title: 'Vente & Stratégie',
    description: 'Bénéficiez d’une valorisation haut de gamme de votre bien et d’une commercialisation ciblée, confidentielle ou grand public.',
    iconName: 'DollarSign'
  },
  {
    id: 'serv-3',
    title: 'Gestion Locative Premium',
    description: 'Sélection rigoureuse des locataires, dossiers sécurisés, entretien de standing et versement optimal garanti de vos loyers.',
    iconName: 'Key'
  },
  {
    id: 'serv-4',
    title: 'Conseil Patrimonial',
    description: 'Optimisation fiscale, restructuration d’actifs de familles ou d’entreprises grâce à d’éminents experts de l’immobilier.',
    iconName: 'TrendingUp'
  }
];
